/*
 * FNgramSpecsUnsigned.cc --
 *	Instantiation of FNgramSpecs<unsigned>
 */

#ifndef lint
static char Copyright[] = "Copyright (c) 1996, SRI International.  All Rights Reserved.";
static char RcsId[] = "@(#)$Header: /home/srilm/CVS/srilm/flm/src/FNgramSpecsInt.cc,v 1.6 2006/08/11 20:47:15 stolcke Exp $";
#endif

#include "FNgramSpecs.cc"
#ifdef INSTANTIATE_TEMPLATES
INSTANTIATE_FNGRAMSPECS(FNgramCount);
#endif

